package jdbcproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateTable {
    public static void main(String[] args) {

        try {
            // Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Create Connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/company",
                    "root",
                    "1234");

            // Create Statement
            Statement stmt = con.createStatement();

            // SQL Query
            String sql = "CREATE TABLE employee (" +
                         "id INT PRIMARY KEY, " +
                         "name VARCHAR(50), " +
                         "salary DOUBLE)";

            // Execute Query
            stmt.executeUpdate(sql);

            System.out.println("Table Created Successfully!");

            // Close Connection
            con.close();

        } catch (Exception e) {
            e.printStackTrace();   // Better error display
        }
    }
}